<!DOCTYPE html>
<html>
<head>
	<title>Cruise Planners</title>

	<!-- Vendor Files -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap-4.1/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>">

	<script type="text/javascript" src="<?php echo e(asset('vendor/jquery-3.2.1.min.js')); ?>"></script>

	<?php echo $__env->yieldContent('head-custom'); ?>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

	<div class="layout-container">
		<div class="container">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
	

	<?php echo $__env->yieldContent('footer-custom'); ?>
</body>
</html>